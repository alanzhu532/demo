downloadFile(token: string, url: string) {
    try {
      let headers = new HttpHeaders()
        .set(
          'Authorization',
          `Bearer ${token}`
        )
        .set('Accept', 'text/csv');
      this.http
        .get(`${url}`, {
          headers: headers,
          responseType: 'blob'
        })
        .subscribe(
        data => {
            // Without File name
            /*console.log('success', data);
            const blob = new Blob([data], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            window.open(url);*/

            // With FileName
            const blob: Blob = new Blob([data], { type: 'text/csv' });
            const fileName = 'budget.csv';
            const objectUrl: string = URL.createObjectURL(blob);
            const a: HTMLAnchorElement = document.createElement('a') as HTMLAnchorElement;

            a.href = objectUrl;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();

            document.body.removeChild(a);
            URL.revokeObjectURL(objectUrl);
          },
          error => console.log('oops', error)
        );
    } catch (error) {
      console.log(error);
      throw error;
    }
  }
