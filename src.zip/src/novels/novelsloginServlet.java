package novels;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.*;
import javax.servlet.http.*; 

import java.sql.SQLException;

import java.io.PrintWriter; 
   
/**
 * Servlet implementation class loginServlet 
 */
   
//@WebServlet("/loginServlet")
public final class novelsloginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public novelsloginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#getServletConfig()
	 */
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @see Servlet#getServletInfo()
	 */
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null; 
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response); 
		
		String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        String contextPath = request.getContextPath();
        
        String destPage = "www.google.ca";
        
        String homePage = "home.jsp"; 
        
        try {
            
            if (username != null) {
                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                //destPage = "http://192.168.81.132:7001/novels/browse";
                /* 
                response.setContentType("text/html");  
                PrintWriter out=response.getWriter();  
                
                //RequestDispatcher dispatcher = request.getRequestDispatcher(contextPath+"/browse/");
                //dispatcher.forward(request, response);
                
                //request.getRequestDispatcher(contextPath+"/userInfo.jsp").forward(request, response);  
                
                //response.sendRedirect(contextPath+"/"+homePage);
                
                out.print("Welcome "+ username);  
                out.println("Context Path - "+contextPath);
                
                out.close();  
                */ 
                
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<html>");
                out.println("<body>");
                out.println("<head>");
                out.println("<title>User Profile</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h3>@User Information </h3>"); 
                out.println("Username: " + request.getParameter("username"));
                out.println("Method: " + request.getMethod());
                out.println("Request URI: " + request.getRequestURI());
                out.println("Protocol: " + request.getProtocol());
                out.println("PathInfo: " + request.getPathInfo());
                out.println("Remote Address: " + request.getRemoteAddr());
                out.println("</body>");
                out.println("</html>");
                
            } else { 
                String message = "Invalid user/password";
                request.setAttribute("message", message);
            }
            
             
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
	
	}
	
	/**
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doHead(HttpServletRequest, HttpServletResponse)
	 */
	protected void doHead(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doTrace(HttpServletRequest, HttpServletResponse)
	 */
	protected void doTrace(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
